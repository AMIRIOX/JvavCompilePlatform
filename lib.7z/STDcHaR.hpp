/*
 * @Author: AMIRIOX無暝 
 * @Date: 2020-06-09 23:15:16 
 * @Last Modified by:   AMIRIOX無暝 
 * @Last Modified time: 2020-06-09 23:15:16 
 */
//! because of history
// #ifndef _STDCHAR_HPP_
// #define _STDCHAR_HPP_

// #include <bits/stdc++.h>
// #include "basetype.hpp"
// #include "STDsTrInG.hpp"

// #include "STDiNt.hpp"
// #include "STDeRrOr.hpp"
// #include "STDbOoL.hpp"
// #include "STDcHaR.hpp"
// #include "STDsTrInG.hpp"
// #include "STDnum.hpp"


// class iNt;
// class dOuBlE;
// class bOoL;
// class sTrInG;
// class cHaR;
// class syntaxError;
// class BasCast;

// class cHaR {
//    private:
//     char value;

//    public:
//     cHaR() = delete;
//     explicit cHaR(char origin) : value(origin) {}
//     char getValue () { return value; }
//     sTrInG operator+(cHaR& other) {
//         std::string tmp;
//         tmp+=value;
//         tmp+=(other.getValue());
//         return tmp;
//     }
//     void operator+(iNt& other) {
//         // isError=true;
//         throw BadCast("cHaR + iNt is not allowed.");
//     }
// };

// #endif